package application.model;

import application.MainApp;

public interface AppController {

	public void setMainApp(MainApp mainApp);
	
	
}
